plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "bg.mihail.nobrawl"
    compileSdk = 34

    defaultConfig {
        applicationId = "bg.mihail.nobrawl"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Един и същ ключ винаги: Device Owner приложение не може да се обнови,
    // ако подписът се смени. Не губи nobrawl.jks!
    signingConfigs {
        create("main") {
            storeFile = file("nobrawl.jks")
            storePassword = "nobrawl123"
            keyAlias = "nobrawl"
            keyPassword = "nobrawl123"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("main")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("main")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
