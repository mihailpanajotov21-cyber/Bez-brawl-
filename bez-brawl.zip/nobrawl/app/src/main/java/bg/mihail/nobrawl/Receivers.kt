package bg.mihail.nobrawl

import android.app.admin.DeviceAdminReceiver
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller

/** Вика се, когато приложението стане Device Owner. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Blocker.setup(context)
        Blocker.enforce(context)
    }
}

/** След рестарт или обновяване на приложението. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Blocker.setup(context)
        Blocker.enforce(context)
    }
}

/** Резултат от изтриването; при неуспех скрива играта. */
class UninstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        if (status != PackageInstaller.STATUS_SUCCESS) Blocker.hideFallback(context)
    }
}

/** Резервна периодична проверка. */
class EnforceJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Blocker.enforce(this)
        if (Blocker.isOwner(this)) Blocker.startGuard(this)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = false
}
