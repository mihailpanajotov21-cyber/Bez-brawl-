package bg.mihail.nobrawl

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (Blocker.isOwner(this)) {
            Blocker.setup(this)
            Blocker.enforce(this)
        }
        render()
    }

    private fun label(s: String, size: Float = 16f): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setPadding(0, 16, 0, 16)
        root.addView(v)
        return v
    }

    private fun button(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { onClick() }
        root.addView(b)
        return b
    }

    private fun passwordField(hintText: String): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        root.addView(e)
        return e
    }

    private fun render() {
        root.removeAllViews()
        label("Без Brawl", 26f)

        if (!Blocker.isOwner(this)) {
            label("Приложението още не е Device Owner, затова не може да блокира.\n\nСвържи телефона с лаптопа и пусни:")
            val cmd = label("adb shell dpm set-device-owner $packageName/.AdminReceiver", 14f)
            cmd.setTextIsSelectable(true)
            cmd.typeface = Typeface.MONOSPACE
            return
        }

        label("✅ Защитата е включена.\nBrawl Stars се трие веднага щом се инсталира.")
        label(
            if (Blocker.isPresent(this)) "Brawl Stars в момента: открит, трие се…"
            else "Brawl Stars в момента: няма го"
        )

        if (!Passwords.isSet(this)) {
            label("Парола за премахване", 20f)
            label("Нека някой друг я въведе и я запази за себе си. Докато няма парола, защитата може да се махне без нея.")
            val p1 = passwordField("Парола")
            val p2 = passwordField("Повтори паролата")
            button("Запази паролата") {
                val a = p1.text.toString()
                when {
                    a.length < 4 -> toast("Поне 4 знака")
                    a != p2.text.toString() -> toast("Паролите не съвпадат")
                    else -> {
                        Passwords.set(this, a)
                        toast("Паролата е запазена")
                        render()
                    }
                }
            }
            button("Махни защитата (без парола)") { confirmRemove() }
        } else {
            label("Премахване на защитата", 20f)
            val p = passwordField("Парола")
            button("Махни защитата") {
                if (Passwords.check(this, p.text.toString())) confirmRemove()
                else toast("Грешна парола")
            }
        }
    }

    private fun confirmRemove() {
        AlertDialog.Builder(this)
            .setMessage("Да махна ли защитата? След това Brawl Stars ще може да се инсталира.")
            .setPositiveButton("Да") { _, _ ->
                Blocker.removeProtection(this)
                toast("Защитата е махната. Сега приложението може да се деинсталира.")
                render()
            }
            .setNegativeButton("Не", null)
            .show()
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }
}
