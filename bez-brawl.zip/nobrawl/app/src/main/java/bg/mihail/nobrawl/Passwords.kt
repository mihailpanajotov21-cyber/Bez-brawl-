package bg.mihail.nobrawl

import android.content.Context
import java.security.MessageDigest

/** Паролата се пази само като хеш. */
object Passwords {
    private fun prefs(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(("nobrawl:$s").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun isSet(c: Context) = prefs(c).contains("h")
    fun set(c: Context, s: String) = prefs(c).edit().putString("h", hash(s)).commit()
    fun check(c: Context, s: String) = prefs(c).getString("h", null) == hash(s)
    fun clear(c: Context) = prefs(c).edit().clear().commit()
}
