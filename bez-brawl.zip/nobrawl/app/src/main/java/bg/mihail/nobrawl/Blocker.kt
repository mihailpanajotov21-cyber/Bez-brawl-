package bg.mihail.nobrawl

import android.Manifest
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Цялата логика: открива Brawl Stars и го трие. */
object Blocker {
    const val TARGET = "com.supercell.brawlstars"
    private const val JOB_ID = 1001

    fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    private fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)

    fun isOwner(c: Context): Boolean = dpm(c).isDeviceOwnerApp(c.packageName)

    fun isPresent(c: Context): Boolean = try {
        c.packageManager.getApplicationInfo(TARGET, PackageManager.MATCH_UNINSTALLED_PACKAGES)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Трие играта тихо (Device Owner не пита за потвърждение). */
    fun enforce(c: Context) {
        if (!isOwner(c) || !isPresent(c)) return
        try {
            val pi = PendingIntent.getBroadcast(
                c, 0, Intent(c, UninstallResultReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            c.packageManager.packageInstaller.uninstall(TARGET, pi.intentSender)
        } catch (e: Exception) {
            hideFallback(c)
        }
    }

    /** Ако изтриването не стане — поне скрива играта, за да не може да се отвори. */
    fun hideFallback(c: Context) {
        if (!isOwner(c)) return
        runCatching { dpm(c).setApplicationHidden(admin(c), TARGET, true) }
    }

    /** Защитава приложението и пуска наблюдението. */
    fun setup(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        runCatching { d.setUninstallBlocked(a, c.packageName, true) }
        if (Build.VERSION.SDK_INT >= 30) {
            // Спира „Принудително спиране“ и „Изчистване на данни“ за това приложение
            runCatching { d.setUserControlDisabledPackages(a, listOf(c.packageName)) }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            runCatching {
                d.setPermissionGrantState(
                    a, c.packageName, Manifest.permission.POST_NOTIFICATIONS,
                    DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED
                )
            }
        }
        scheduleJob(c)
        startGuard(c)
    }

    fun startGuard(c: Context) {
        runCatching { c.startForegroundService(Intent(c, GuardService::class.java)) }
    }

    /** Резервна проверка на всеки 15 минути, ако HyperOS убие услугата. */
    private fun scheduleJob(c: Context) {
        val js = c.getSystemService(JobScheduler::class.java)
        if (js.getPendingJob(JOB_ID) != null) return
        val job = JobInfo.Builder(JOB_ID, ComponentName(c, EnforceJob::class.java))
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .build()
        js.schedule(job)
    }

    /** Маха всичко и спира да е Device Owner. След това приложението се трие нормално. */
    fun removeProtection(c: Context) {
        val d = dpm(c)
        val a = admin(c)
        c.getSystemService(JobScheduler::class.java).cancel(JOB_ID)
        c.stopService(Intent(c, GuardService::class.java))
        runCatching { d.setUninstallBlocked(a, c.packageName, false) }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching { d.setUserControlDisabledPackages(a, emptyList()) }
        }
        runCatching { d.setApplicationHidden(a, TARGET, false) }
        Passwords.clear(c)
        runCatching { d.clearDeviceOwnerApp(c.packageName) }
    }
}
